﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Volt_Server
{
    public enum sts { Wire, Buster, amperageDevour, EMP, Rocket, Shield, Radar, Mine, Base };

    public enum mods { None, Tracker, Voltmeter, Worker };
    /*----------------------------------------
     Трекер (союз) - Даёт устаревшую инфу вражескому трекеру
     Трекер (враж) - Даёт информацию о постройке
     Вольтметер (союз) - Не даёт вражескому вольтметру собрать информацию о союзном наличии заряда на этом строении
     Вольтметер (враж) - Даёт информацию об наличии заряда на строении
     Воркер (союз) - Не позволяет врагу заблокировать работу вашей постройки
     Воркер (враж) - Блокирует работу постройки
     ----------------------------------------*/

    public class Structures
    {
        public sts Type = 0;
        public bool Load = false;
        public int timeToWork = 0;
        public int Worked = 0;
        public int Player = 0;
        public bool defaultActive = false;
        public bool currentActive;
        public bool[] Connections; //0 - Top, 1 - Right, 2 - Bottom, 3 - Left
        public int sprite = 0;
        public int Rotation = 0;
        public int posX;
        public int posY;
        public int targetX = -1;
        public int targetY = -1;
        public mods playerMod = mods.None;
        public mods enemyMod = mods.None;
        public int shopIndex;
        public int Level;
        public int Health;

        public Structures()
        {
            Type = (sts)0;
            Load = false;
            timeToWork = 0;
            Worked = 0;
            Player = 0;
            defaultActive = false;
            currentActive = false;
            sprite = 0;
            Rotation = 0;
            posX = 0;
            posY = 0;
            targetX = -1;
            targetY = -1;
            playerMod = mods.None;
            enemyMod = mods.None;
            shopIndex = 0;
            Connections = new bool[4] { false, false, false, false };
            Level = 1;
            Health = 1;
        }

        public void rotateRight()
        {
            bool[] res = new bool[4];
            for (int i = 0; i < 4; i++)
            {
                res[i] = Connections[(3 + i) % 4];
            }
            for (int i = 0; i < 4; i++)
            {
                Connections[i] = res[i];
            }
        }

        public void rotateLeft()
        {
            bool[] res = new bool[4];
            for (int i = 0; i < 4; i++)
            {
                res[i] = Connections[(i + 1) % 4];
            }
            for (int i = 0; i < 4; i++)
            {
                Connections[i] = res[i];
            }
        }

        public bool allSide()
        {
            bool res = true;

            for (int i = 0; i < 4; i++)
            {
                if (!Connections[i]) { res = false; break; }
            }

            return res;
        }
    }
}
