﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Volt_Server
{
    class GameLogic
    {
        public static void Update()
        {
            ThreadManager.UpdateMain();
            if (Server.GL != null) Server.GL.timeOutStage();
        }
    }
}
