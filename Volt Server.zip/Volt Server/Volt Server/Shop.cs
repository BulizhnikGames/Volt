﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Numerics;

namespace Volt_Server
{
    public class Shop
    {
        private int[] maxAmaunt = new int[4] { 5, 4, 4, 2 }; //Volt devaur, EMP, Rocket launcher, Rocket shield
        public static int[] Prices = new int[10] { 10, 10, 40, 200, 110, 220, 300, 200, 150, 250 }; //Two sides wire, Corner wire (Base), All sides wire, Buster, Volr devour, EMP, Rocket launcher, Rocket shield, Radar, Mine
        public int[] PlayerAll = new int[10] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        public int[] PlayerPlaced = new int[10] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        public int[] maxMods = new int[3] { 7, 7, 7 };
        public int[] modsPlaced = new int[3] { 0, 0, 0 };
        public int Gold = 1000;

        public Player player;

        public void Start()
        {
            addGold(0);
        }

        public void Buy(int index)
        {
            if (Gold >= Prices[index])
            {
                if (index >= 4 && index <= 7)
                {
                    if (PlayerAll[index] < maxAmaunt[index - 4])
                    {
                        addGold(-Prices[index]);
                        PlayerAll[index]++;
                        ServerSend.structPayed(player.id, index, allCanBuy(), canPlace(index), Gold, inInventory());
                    }
                }
                else
                {
                    addGold(-Prices[index]);
                    PlayerAll[index]++;
                    ServerSend.structPayed(player.id, index, allCanBuy(), canPlace(index), Gold, inInventory());
                }
            }
        }

        public void Sell(int x, int y)
        {
            Structures s = player.GL.Field[x, y];
            int index = s.shopIndex;

            addGold(Prices[index] / 2);
            PlayerAll[index]--;
            PlayerPlaced[index]--;

            returnMods(s);
            ServerSend.structPayed(player.id, index, allCanBuy(), canPlace(index), Gold, inInventory());
        }

        public bool canBuy(int index)
        {
            bool res = false;

            if (Gold >= Prices[index])
            {
                if (index >= 4 && index <= 7)
                {
                    if (PlayerAll[index] < maxAmaunt[index - 4])
                    {
                        res = true;
                    }
                }
                else
                {
                    res = true;
                }
            }

            return res;
        }

        public bool[] allCanBuy()
        {
            bool[] res = new bool[Prices.Length];
            for (int i = 0; i < Prices.Length; i++) res[i] = Gold >= Prices[i] && (!(i >= 4 && i <= 7) || PlayerAll[i] < maxAmaunt[i - 4]);
            return res;
        }

        public void addGold(int add)
        {
            Gold += add;
            // TODO: Send add gold packet
        }

        public bool canPlace(int index)
        {
            //Console.WriteLine($"player placed {PlayerPlaced[index]}, player all {PlayerAll[index]} => {PlayerPlaced[index] < PlayerAll[index]}");
            return PlayerPlaced[index] < PlayerAll[index];
        }

        public void Place(int index)
        {
            PlayerPlaced[index]++;
        }

        public void Remove(int x, int y)
        {
            Structures s = player.GL.Field[x, y];
            int index = s.shopIndex;

            PlayerPlaced[index]--;

            returnMods(s);
            ServerSend.changeCanPlace(player.client.id, index, canPlace(index), false, inInventory());
        }

        public void Destroy(int index)
        {
            PlayerPlaced[index]--;
            PlayerAll[index]--;
            ServerSend.changeCanPlace(player.client.id, index, canPlace(index), false, inInventory());
        }

        public int[] inInventory()
        {
            int[] res = new int[PlayerAll.Length];
            for (int i = 0; i < res.Length; i++) res[i] = PlayerAll[i] - PlayerPlaced[i];
            return res;
        }

        private void returnMods(Structures s)
        {
            Shop p = Server.clients[s.Player].player.shop;
            Shop e = Server.clients[p.player.enemyId].player.shop;

            int pMod = (int)s.playerMod;
            int eMod = (int)s.enemyMod;

            if (pMod != 0) p.modsPlaced[pMod]--;
            if (eMod != 0) e.modsPlaced[eMod]--;
        }
    }
}
