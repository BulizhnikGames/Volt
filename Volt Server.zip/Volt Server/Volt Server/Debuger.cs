﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Volt_Server
{
    public static class Debuger
    {
        /*
        0 - Get players names
        1 - Get Field
        2 - Get struct info
        3 - Get player's inventory
        4 - Get player's code
        5 - Remove stage time limit
        6 - Skip stage
        */

        static volatile bool exit = false;

        public static void Debug()
        {
            Task.Factory.StartNew(() => { });

            while (!exit)
            {
                string[] a = Console.ReadLine().Split();

                int[] arg = new int[a.Length];
                for (int i = 0; i < a.Length; i++) arg[i] = int.Parse(a[i]);

                if (arg[0] == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Green;

                    int count = 0;
                    List<string> playersInfo = new List<string>();
                    foreach (Client c in Server.clients.Values)
                    {
                        if (c.player == null) continue;
                        count++;
                        Player p = c.player;
                        playersInfo.Add($"Player: id - {p.id}, username - {p.Username}, ready - {p.Ready}");
                    }
                    if (Server.GL != null) Console.WriteLine($"Stage: {Server.GL.currentStage}, {Server.GL.stageEnd - DateTime.Now} remaining");
                    Console.WriteLine($"Players on server: {count}");
                    for (int i = 0; i < playersInfo.Count; i++) Console.WriteLine(playersInfo[i]);

                    Console.ForegroundColor = ConsoleColor.White;
                }
                else if (arg[0] == 1 && arg.Length == 2)
                {
                    Console.ForegroundColor = ConsoleColor.Red;

                    if (Server.GL == null) Console.WriteLine("NO FIELD!");
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        for (int y = Constants.fieldSizeY - 1; y >= 0; y--)
                        {
                            string str = "";
                            for (int x = 0; x < Constants.fieldSizeX; x++)
                            {
                                if (Server.GL.Field[x, y] != null && arg[1] != 2)
                                {
                                    if (arg[1] == 0) str += $"{(int)Server.GL.Field[x, y].Type} ";
                                    else if (arg[1] == 1) str += Server.GL.Field[x, y].Player.ToString() + " ";
                                    else str += Server.Ter.Ter[x, y] + " ";
                                }
                                else
                                {
                                    if (arg[1] == 2 && Server.Ter.Ter[Math.Min(Constants.fieldSizeX - 1, x + 1), y] != Server.Ter.Ter[x, y])
                                    {
                                        str += $"{Server.Ter.Ter[x, y]} {Server.Ter.Ter[x + 1, y]} ";
                                        x++;
                                    }
                                    else str += "- ";
                                }
                            }
                            Console.WriteLine(str);
                        }
                    }

                    Console.ForegroundColor = ConsoleColor.White;
                }
                else if (arg[0] == 2 && arg.Length == 3)
                {
                    int x = arg[1];
                    int y = arg[2];

                    Console.ForegroundColor = ConsoleColor.Red;

                    if (Server.GL == null) Console.WriteLine("FIELD NOT GENERATED YET!");
                    else
                    {
                        Structures s = Server.GL.Field[x, y];

                        if (s == null) Console.WriteLine($"THERE'S NO STRUCT ON {x}, {y}!");
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine($"Type: {s.Type.ToString().ToLower()}");
                            Console.WriteLine($"Player: {s.Player}, {Server.clients[s.Player].player.Username}");
                            Console.WriteLine($"Connections: {s.Connections[0]}, {s.Connections[1]}, {s.Connections[2]}, {s.Connections[3]}");
                            Console.WriteLine($"Rotation: {s.Rotation}");
                            Console.WriteLine($"Target: {s.targetX}, {s.targetY}");
                            Console.WriteLine($"Mods: {s.playerMod}, {s.enemyMod}");
                            Console.WriteLine($"Shop index: {s.shopIndex}");
                        }
                    }

                    Console.ForegroundColor = ConsoleColor.White;
                }
                else if (arg[0] == 3 && arg.Length == 2)
                {
                    int id = arg[1];

                    Console.ForegroundColor = ConsoleColor.Red;

                    if (!Server.clients.ContainsKey(id) ||Server.clients[id].player == null) Console.WriteLine($"THERE'S NO PLAYERS WITH ID {id}");
                    else
                    {
                        Shop s = Server.clients[id].player.shop;
                        Console.ForegroundColor = ConsoleColor.Green;

                        string str = "All structs: ";
                        for (int i = 0; i < s.PlayerAll.Length; i++) str += $"{s.PlayerAll[i]} ";
                        Console.WriteLine(str);

                        str = "Placed structs: ";
                        for (int i = 0; i < s.PlayerPlaced.Length; i++) str += $"{s.PlayerPlaced[i]} ";
                        Console.WriteLine(str);

                        str = "Placed mods: ";
                        for (int i = 0; i < s.modsPlaced.Length; i++) str += $"{s.modsPlaced[i]} ";
                        Console.WriteLine(str);

                        Console.WriteLine($"Gold: {s.Gold}");
                    }

                    Console.ForegroundColor = ConsoleColor.White;
                }
                else if (arg[0] == 4 && arg.Length == 2)
                {
                    int id = arg[1];

                    Console.ForegroundColor = ConsoleColor.Red;

                    if (!Server.clients.ContainsKey(id) || Server.clients[id].player == null) Console.WriteLine($"THERE'S NO PLAYERS WITH ID {id}");
                    else
                    {
                        Block[] Code = Server.clients[id].player.Code;

                        for (int i = 0; i < Code.Length; i++)
                        {
                            if (Code[i] != null)
                            {
                                switch ((int)Code[i].Type)
                                {
                                    case 0:
                                    case 1:
                                    case 2:
                                    case 3:
                                        Console.ForegroundColor = ConsoleColor.Blue;
                                        break;
                                    case 4:
                                    case 5:
                                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                                        break;
                                    case 6:
                                    case 7:
                                    case 8:
                                    case 9:
                                        Console.ForegroundColor = ConsoleColor.Blue;
                                        break;
                                    case 10:
                                        Console.ForegroundColor = ConsoleColor.Green;
                                        break;
                                }
                                if (Code[i].Type != blockTypes.startRepeat) Console.WriteLine($"{i + 1}. {Code[i].Type.ToString().ToLower()}");
                                else Console.WriteLine($"{i + 1}. {Code[i].Type.ToString().ToLower()} ({Code[i].Par})");
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine($"{i + 1}. none");
                            }
                        }
                    }

                    Console.ForegroundColor = ConsoleColor.White;
                }
                else if (arg[0] == 5)
                {
                    if (Server.GL != null)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;

                        Server.GL.stageTimeLim = !Server.GL.stageTimeLim;
                        Console.WriteLine($"Stage time lim setted to {Server.GL.stageTimeLim}");
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("THERE'S NO GL");
                    }

                    Console.ForegroundColor = ConsoleColor.White;
                }
                else if (arg[0] == 6)
                {
                    if (Server.GL != null)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;

                        Console.WriteLine($"Changed Stage to {(Stages)(((int)Server.GL.currentStage + 1) % 3)}");

                        Server.GL.changeStage(true, 0);
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("THERE'S NO GL");
                    }

                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
        }
    }
}
