﻿using System;
using System.Numerics;

namespace Volt_Server
{
    class ServerSend
    {
        private static void sendTCPData(int _toClient, Packet _packet)
        {
            _packet.WriteLength();
            Server.clients[_toClient].tcp.sendData(_packet);
        }

        private static void sendTCPDataToAll(Packet _packet)
        {
            _packet.WriteLength();

            for (int i = 1; i <= Server.maxPlayers; i++)
            {
                Server.clients[i].tcp.sendData(_packet);
            }
        }

        #region Packets

        public static void Welcome(int _toClient, string _msg)
        {
            using (Packet _packet = new Packet((int)ServerPackets.welcome))
            {
                _packet.Write(_msg);
                _packet.Write(_toClient);

                sendTCPData(_toClient, _packet);
            }
        }

        public static void spawnPlayer(int toClient, Player player)
        {
            using (Packet _packet = new Packet((int)ServerPackets.spawnPlayer))
            {
                _packet.Write(player.id);
                _packet.Write(player.Username);

                sendTCPData(toClient, _packet);
            }
        }

        public static void structPayed(int _toClient, int index, bool[] newCanBuy, bool newCanPlace, int newGold, int[] amount)
        {
            using (Packet _packet = new Packet((int)ServerPackets.structPayed))
            {
                _packet.Write(index);
                _packet.Write(newCanPlace);

                _packet.Write(newCanBuy.Length);
                for (int i = 0; i < newCanBuy.Length; i++) _packet.Write(newCanBuy[i]);

                _packet.Write(newGold);

                _packet.Write(amount.Length);
                for (int i = 0; i < amount.Length; i++) _packet.Write(amount[i]);

                sendTCPData(_toClient, _packet);
            }
        }

        public static void setStruct(Structures s)
        {
            using (Packet _packet = new Packet((int)ServerPackets.placeStructObj))
            {
                _packet.Write(s);

                sendTCPDataToAll(_packet);
            }
        }

        public static void devideTerrs(int[,] Ter, Vector2[] splitPrices)
        {
            using (Packet _packet = new Packet((int)ServerPackets.devideTerritory))
            {
                for (int x = 0; x < Constants.fieldSizeX; x++)
                {
                    for (int y = 0; y < Constants.fieldSizeY; y++)
                    {
                        _packet.Write(Ter[x, y]);
                    }
                }

                for (int i = 0; i < Constants.fieldSizeY; i++)
                {
                    _packet.Write(splitPrices[i]);
                }

                sendTCPDataToAll(_packet);
            }
        }

        public static void changeCanPlace(int _toClient, int index, bool newValue, bool Building, int[] amount)
        {
            using (Packet _packet = new Packet((int)ServerPackets.changeCanPlace))
            {
                _packet.Write(index);
                _packet.Write(newValue);
                _packet.Write(Building);
                _packet.Write(amount.Length);
                for (int i = 0; i < amount.Length; i++) _packet.Write(amount[i]);

                sendTCPData(_toClient, _packet);
            }
        }

        public static void removeStruct(int x, int y)
        {
            using (Packet _packet = new Packet((int)ServerPackets.removeStruct))
            {
                _packet.Write(x);
                _packet.Write(y);

                sendTCPDataToAll(_packet);
            }
        }

        public static void codeRunned(int _toClient, gameStatus[] result)
        {
            using (Packet _packet = new Packet((int)ServerPackets.codeResult))
            {
                Console.WriteLine($"Sending endCode packet to player {_toClient} Length = {result.Length}");

                _packet.Write(result.Length);

                for (int i = 0; i < result.Length; i++)
                {
                    _packet.Write(result[i]);
                }

                Player p = Server.clients[_toClient].player;

                int Length = p.debugTexts.Count;
                _packet.Write(Length);

                for (int i = 0; i < Length; i++)
                {
                    _packet.Write(Server.clients[_toClient].player.debugTexts[i]);
                    _packet.Write(Server.clients[_toClient].player.debugIcons[i]);
                }

                Length = p.debugPos.Count;
                _packet.Write(Length);

                foreach (int k in p.debugPos.Keys)
                {
                    _packet.Write(k);
                    _packet.Write(p.debugPos[k]);
                }

                sendTCPData(_toClient, _packet);
            }
        }

        public static void applyMod(int _toClient, int posX, int posY, int newMod, bool isOwner, bool changeAmount)
        {
            using (Packet _packet = new Packet((int)ServerPackets.applyMod))
            {
                Console.WriteLine($"Sending mode to {Server.clients[_toClient].player.Username} mod {(mods)newMod} owner {isOwner}");

                _packet.Write(posX);
                _packet.Write(posY);
                _packet.Write(newMod);
                _packet.Write(isOwner);

                _packet.Write(changeAmount); 
                if (changeAmount)
                {
                    Shop s = Server.clients[_toClient].player.shop;
                    _packet.Write(s.maxMods.Length);
                    for (int i = 0; i < s.maxMods.Length; i++)
                    {
                        _packet.Write(s.maxMods[i] - s.modsPlaced[i]);
                    }
                }

                sendTCPData(_toClient, _packet);
            }
        }

        public static void sendNewStage(int newStage, long Ticks)
        {
            using (Packet _packet = new Packet((int)ServerPackets.changeStage))
            {
                Console.WriteLine($"Stage changed to {(Stages)newStage}");

                _packet.Write(newStage);
                _packet.Write(Ticks);

                sendTCPDataToAll(_packet);
            }
        }

        public static void applyReady(int id)
        {
            using (Packet _packet = new Packet((int)ServerPackets.applyReady))
            {
                _packet.Write(id);
                _packet.Write(Server.clients[id].player.Ready);

                sendTCPDataToAll(_packet);
            }
        }

        public static void updateTarget(int _toClient, Structures update)
        {
            using (Packet _packet = new Packet((int)ServerPackets.updateTarget))
            {
                _packet.Write(update.posX);
                _packet.Write(update.posY);

                _packet.Write(update.targetX);
                _packet.Write(update.targetY);

                sendTCPData(_toClient, _packet);
            }
        }

        public static void applyRotation(int x, int y, int r)
        {
            using (Packet _packet = new Packet((int)ServerPackets.applyRotation))
            {
                _packet.Write(x);
                _packet.Write(y);

                _packet.Write(r);

                sendTCPDataToAll(_packet);
            }
        }

        public static void gameEnd(int _toClient, bool win)
        {
            using (Packet _packet = new Packet((int)ServerPackets.gameEnd))
            {
                _packet.Write(win);

                sendTCPData(_toClient, _packet);
            }
        }

        public static void changeCanBuy(int _toClient, bool[] arr)
        {
            using (Packet _packet = new Packet((int)ServerPackets.changeCanBuy))
            {
                _packet.Write(arr.Length);

                for (int i = 0; i < arr.Length; i++)
                {
                    _packet.Write(arr[i]);
                }

                sendTCPData(_toClient, _packet);
            }
        }
        #endregion
    }
}
