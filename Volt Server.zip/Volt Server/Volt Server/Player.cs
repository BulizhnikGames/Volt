﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Numerics;
using System.Collections;

namespace Volt_Server
{
    public class Player
    {
        public int id;
        public int enemyId = 9999;
        public string Username;

        public Client client;

        public structurePlacer sp;
        public Shop shop;

        public Load playerLoad;

        public Block[] Code;
        public List<Block> blockList;

        public int maxCodeLength = 20;
        public int maxCompletedCommands = 200;

        public List<string> debugTexts;
        public List<int> debugIcons;
        public Dictionary<int, Vector2> debugPos;

        public int completedCommands = 0;

        public gameStatus[] codeResult;
        public bool cr = false;

        public gameLoop GL;

        public bool Ready = false;

        public bool leftBot;

        public Player(int _id, string _username)
        {
            id = _id;
            Username = _username;

            shop = new Shop();
            sp = new structurePlacer();

            shop.player = this;
            sp.player = this;

            Code = new Block[maxCodeLength];

            debugTexts = new List<string>();
            debugIcons = new List<int>();
            debugPos = new Dictionary<int, Vector2>();

            shop.Start();
        }

        private Load initLoad()
        {
            Load l = new Load();
            l.GL = GL;
            l.player = this;
            l.Rotation = (leftBot) ? dirs.Up : dirs.Down;
            return l;
        }

        public void runCode()
        {
            completedCommands = 0;

            Block lastBlock = null;
            int First = 0;
            for (int i = 0; i < Code.Length; i++)
            {
                if (Code[i] != null)
                {
                    Code[i].Line = i;

                    if (Code[i].conLine < i && Code[i].conLine >= 0)
                    {
                        Code[Code[i].conLine].Connected = Code[i];
                        Code[i].Connected = Code[Code[i].conLine];
                    }

                    if (i > First && First == 0 && Code[0] == null) First = i;

                    Code[i].GL = GL;
                    Code[i].player = this;

                    if (lastBlock != null) lastBlock.nextBlock = Code[i];
                    lastBlock = Code[i];
                }
            }

            if (lastBlock != null)
            {
                GL.toExec.Add(Code[First]);
            }
        }

        public void activeField(int a)
        {
            completedCommands++;

            int x = (int)playerLoad.Position.X;
            int y = (int)playerLoad.Position.Y;

            Structures s = GL.Field[x, y];

            GL.toActive.Add(s);
        }

        public void codeRunned()
        {
            for (int i = 0; i < Code.Length; i++)
            {
                if (Code[i] != null) Code[i].cyclesPassed = 0;
            }

            playerLoad = null;

            cr = false;

            ServerSend.changeCanBuy(id, shop.allCanBuy());
        }

        public void moveUnit(blockTypes BT)
        {
            switch (BT)
            {
                case blockTypes.moveUp:
                    playerLoad.moveUp();
                    break;
                case blockTypes.moveDown:
                    playerLoad.moveDown();
                    break;
                case blockTypes.moveRight:
                    playerLoad.moveRight();
                    break;
                case blockTypes.moveLeft:
                    playerLoad.moveLeft();
                    break;
                case blockTypes.turnRight:
                    playerLoad.turnRight();
                    break;
                case blockTypes.turnLeft:
                    playerLoad.turnLeft();
                    break;
                case blockTypes.Forward:
                    playerLoad.moveForward();
                    break;
                case blockTypes.Bakcward:
                    playerLoad.moveBackward();
                    break;
            }
        }

        public bool canGoOn()
        {
            return completedCommands < maxCompletedCommands;
        }

        public void initForCode()
        {
            codeResult = new gameStatus[maxCompletedCommands + 1];

            for (int i = 0; i < codeResult.Length; i++)
            {
                codeResult[i] = new gameStatus();
            }

            playerLoad = initLoad();
        }

        public void endOfCode()
        {
            Console.WriteLine($"Player's {id} code got to the end");
        }
    }
}
