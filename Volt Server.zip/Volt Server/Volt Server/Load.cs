﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Numerics;

public enum dirs { Up, Right, Down, Left };

namespace Volt_Server
{
    public class Load
    {
        public gameLoop GL;
        public Player player;
        public Vector2 Position = new Vector2(0, 0);
        public dirs Rotation;

        public void moveUp()
        {
            Move(new Vector2(0, 1));
        }

        public void moveDown()
        {
            Move(new Vector2(0, -1));
        }

        public void moveRight()
        {
            Move(new Vector2(1, 0));
        }

        public void moveLeft()
        {
            Move(new Vector2(-1, 0));
        }

        public void turnRight()
        {
            Rotation = (dirs)(((int)Rotation + 1) % 4);
            player.completedCommands++;
            player.codeResult[GL.Queue].loadRot = 1;
            player.codeResult[GL.Queue].loadPos = player.codeResult[GL.Queue - 1].loadPos;
        }

        public void turnLeft()
        {
            Rotation = (dirs)((3 + (int)Rotation) % 4);
            player.completedCommands++;
            player.codeResult[GL.Queue].loadRot = -1;
            player.codeResult[GL.Queue].loadPos = player.codeResult[GL.Queue - 1].loadPos;
        }

        public void moveForward()
        {
            switch (Rotation)
            {
                case dirs.Up:
                    moveUp();
                    break;
                case dirs.Down:
                    moveDown();
                    break;
                case dirs.Right:
                    moveRight();
                    break;
                case dirs.Left:
                    moveLeft();
                    break;
            }
        }

        public void moveBackward()
        {
            switch (Rotation)
            {
                case dirs.Up:
                    moveDown();
                    break;
                case dirs.Down:
                    moveUp();
                    break;
                case dirs.Right:
                    moveLeft();
                    break;
                case dirs.Left:
                    moveRight();
                    break;
            }
        }

        private void Move(Vector2 to)
        {
            if (GL.checkConnections(Position, Position + to, to, player.id))
            {           
                GL.setLoadInStruct(Position, Position + to, player.id);
                Position += to;
                //transform.position += new Vector3(to.x, to.y, 0);
            }
            else
            {
                string debug = $"{GL.Queue}. CAN'T MOVE BECAUSE OF WRONG CONNECTIONS";
                player.debugTexts.Add(debug);
                player.debugIcons.Add(0);
                player.debugPos.Add(player.debugTexts.Count - 1, Position);

                int q = GL.Queue;
                if (q > 0) player.codeResult[q].loadPos = player.codeResult[q - 1].loadPos;
            }
            //Console.WriteLine($"Player {player.Username} queue {player.Queue} position {Position}");
            player.codeResult[GL.Queue].loadPos = Position;
            player.completedCommands++;
        }

        public override string ToString()
        {
            return "Position = " + Position.ToString() + " direction = " + Rotation.ToString();
        }
    }
}
