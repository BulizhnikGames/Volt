﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Numerics;
using System.Threading.Tasks;

public enum Stages { Building, Modding, Coding, Viewing };

namespace Volt_Server
{
    public class gameLoop
    {
        /*private const int busterRange = 100;
        private const int voltDevourRange = 100;
        private const int empRange = 100;
        private const int rocketLauncherRange = 100;
        private const int rocketShieldRange = 100;
        private const int radarRange = 100;
        private const int goldFromMine = 100;*/

        private const int busterRange = 3;
        private const int voltDevourRange = 100;
        private const int empRange = 5;
        private const int rocketLauncherRange = 100;
        private const int rocketShieldRange = 3;
        private const int radarRange = 2;
        private const int goldFromMine = 15;

        public Structures[,] Field;
        public int fieldSizeX = 40;
        public int fieldSizeY = 20;

        public List<Structures> activeStructs;

        public Territory Ter;

        public List<Block> toExec;
        public List<Structures> toActive;
        public List<Structures> toDestroy;

        public bool bothReady = false;
        public int Queue = 0;

        public Stages currentStage = Stages.Building;
        public DateTime stageEnd;

        public bool stageTimeLim = true;

        public bool win = false;

        public gameLoop()
        {
            win = false;
            currentStage = Stages.Coding;
            changeStage(true, 0);
            initField();
            Queue = 0;
        }

        public void runCode()
        {
            Console.WriteLine($"Starting code");

            toExec = new List<Block>();
            toActive = new List<Structures>();
            toDestroy = new List<Structures>();

            activeStructs = new List<Structures>();

            foreach (Client client in Server.clients.Values)
            {
                Player p = client.player;

                p.initForCode();

                if (client.player.leftBot)
                {
                    p.codeResult[0].loadPos = Vector2.Zero;
                    p.playerLoad.Position = Vector2.Zero;
                }
                else
                {
                    Vector2 Pos = new Vector2(fieldSizeX - 1, fieldSizeY - 1);
                    p.codeResult[0].loadPos = Pos;
                    p.playerLoad.Position = Pos;
                }

                p.runCode();
            }

            initStructs();

            completeTurn();
        }

        public void codeRunned()
        {
            Console.WriteLine("Code runned for both players");

            int Turns = 0;

            foreach (Client client in Server.clients.Values)
            {
                Player p = client.player;

                int lastIndex = 0;

                for (int i = p.maxCompletedCommands; i >= 0; i--)
                {
                    if (p.codeResult[i] != null && !notChangedStatus(p.codeResult[i]))
                    {
                        //Console.WriteLine($"last index {i}, status {p.codeResult[i].ToString()}");
                        lastIndex = i;
                        break;
                    }
                }

                Turns = (lastIndex > Turns) ? lastIndex : Turns;

                gameStatus[] toSend = new gameStatus[lastIndex + 1];
                Array.Copy(p.codeResult, toSend, lastIndex + 1);

                ServerSend.codeRunned(client.id, toSend);

                p.debugTexts = new List<string>();
                p.debugIcons = new List<int>();
                p.debugPos = new Dictionary<int, Vector2>();

                p.codeRunned();
            }

            changeStage(false, Turns);

            Queue = 0;
        }

        public void completeTurn()
        {
            bothReady = false;

            for (int i = 0; i < toActive.Count; i++)
            {
                if (toActive[i] != null) setActive(true, toActive[i], false);
            }

            for (int i = 0; i < toDestroy.Count; i++)
            {
                if (toDestroy[i] != null)
                {
                    int x = toDestroy[i].posX;
                    int y = toDestroy[i].posY;

                    Structures s = Field[x, y];
                    s.Health--;

                    Player p = Server.clients[s.Player].player;

                    if (s.Health == 0)
                    {
                        if (p.id == s.Player && s.Type != sts.Base) p.shop.Destroy(s.shopIndex);

                        if (p.playerLoad.Position == new Vector2(x, y))
                        {
                            p.playerLoad = null;
                            Console.WriteLine($"Player {p.Username} Lose; Player {Server.clients[p.enemyId].player.Username} Win");
                            p.codeResult[Queue].Lose = true;
                            Server.clients[p.enemyId].player.codeResult[Queue].Win = true;
                            win = true;
                        }
                        else if (Field[x, y].Type == sts.Base)
                        {
                            Console.WriteLine($"Player {p.Username} Lose; Player {Server.clients[p.enemyId].player.Username} Win");
                            p.codeResult[Queue].Lose = true;
                            Server.clients[p.enemyId].player.codeResult[Queue].Win = true;
                            win = true;
                        }

                        p.codeResult[Queue].removedStructs.Add(new Vector2(x, y));
                        Server.clients[p.enemyId].player.codeResult[Queue].removedStructs.Add(new Vector2(x, y));

                        Server.clients[p.enemyId].player.codeResult[Queue].Gold += (int)Math.Round(Shop.Prices[s.shopIndex] * 1.5f);

                        Server.GL.Field[x, y] = null;
                    }
                    else
                    {
                        p.codeResult[Queue].removedStructs.Add(new Vector2(x, y));
                        Server.clients[p.enemyId].player.codeResult[Queue].removedStructs.Add(new Vector2(x, y));
                    }
                }
            }

            /*foreach (Client c in Server.clients.Values)
            {
                Console.WriteLine($"{c.player.id}.{Queue} +{c.player.codeResult[Queue].Gold}");
            }*/

            Queue++;
            Console.WriteLine($"Queue {Queue}");

            if (Queue > 200) { codeRunned(); return; } 

            List<Structures> newEMP = new List<Structures>();

            for (int i = 0; i < activeStructs.Count; i++)//Сначала обработка работы EMP
            {
                Structures s = activeStructs[i];
                if (s.Type == sts.EMP)
                {
                    s.Worked--;
                    if (s.Worked > 0)
                    {
                        //activeStructs.Remove(s);
                        newEMP.Add(s);
                    }
                    else
                    {
                        setActive(false, s, true);
                    }
                }
            }

            List<Structures> newAct = new List<Structures>();

            for (int i = 0; i < activeStructs.Count; i++)//Потом обработка остальных строений с учётом рассчётов EMP
            {
                Structures s = activeStructs[i];
                if (s.Type != sts.EMP)
                {
                    s.Worked--;
                    //if (s.Type == sts.Buster) Console.WriteLine($"{s.Player}.{Queue} --");
                    if (s.Worked > 0)
                    {
                        //activeStructs.Remove(s);
                        newAct.Add(s);          
                    }
                    else
                    {
                        setActive(false, s, false);
                    }
                }
            }

            activeStructs = new List<Structures>();

            for (int i = 0; i < newEMP.Count; i++)
            {
                activeStructs.Add(newEMP[i]);
            }

            for (int i = 0; i < newEMP.Count; i++)
            {
                activeStructs.Add(newEMP[i]);
            }

            toActive.Clear();
            toDestroy.Clear();

            if (toExec.Count == 0) { codeRunned(); return; }

            List<Block> E = new List<Block>();
            for (int i = 0; i < toExec.Count; i++)
            {
                E.Add(toExec[i]);
            }
            toExec.Clear();

            for (int i = 0; i < E.Count; i++)
            {
                if (E[i] != null) E[i].Execute();
            }

            completeTurn();
        }

        private void initField()
        {
            Field = new Structures[fieldSizeX, fieldSizeY];

            foreach (Client client in Server.clients.Values)
            {
                Player p = client.player;

                if (p.leftBot)
                {
                    Structures s = new Structures();

                    s.Type = sts.Base;
                    s.timeToWork = -1;
                    s.Player = p.id;
                    s.defaultActive = false;
                    s.Connections = new bool[4] { true, true, false, false };
                    s.sprite = 10;
                    s.posX = 0;
                    s.posY = 0;
                    s.shopIndex = 1;
                    s.Level = 1;
                    s.Health = 2;

                    Field[0, 0] = s;

                    ServerSend.setStruct(s);
                }
                else
                {
                    Structures s = new Structures();

                    s.Type = sts.Base;
                    s.timeToWork = -1;
                    s.Player = p.id;
                    s.defaultActive = false;
                    s.Connections = new bool[4] { false, false, true, true };
                    s.sprite = 12;
                    s.posX = fieldSizeX - 1;
                    s.posY = fieldSizeY - 1;
                    s.shopIndex = 1;
                    s.Level = 1;
                    s.Health = 2;

                    Field[fieldSizeX - 1, fieldSizeY - 1] = s;

                    ServerSend.setStruct(s);
                }
            }
        }  

        private void initStructs()
        {
            for (int x = 0; x < fieldSizeX; x++)
            {
                for (int y = 0; y < fieldSizeY; y++)
                {
                    if (Field[x, y] != null && Field[x, y].defaultActive) toActive.Add(Field[x, y]);
                }
            }
        } 

        public void addToField(Vector2 Pos, Structures s)
        {
            int x = (int)Pos.X;
            int y = (int)Pos.Y;
            Field[x, y] = s;
        }

        public void setLoadInStruct(Vector2 from, Vector2 to, int id)
        {
            int fx = (int)from.X;
            int fy = (int)from.Y;
            int tx = (int)to.X;
            int ty = (int)to.Y;

            Field[fx, fy].Load = false;
            Field[tx, ty].Load = true;

            Server.clients[id].player.codeResult[Queue].loadPos = to;
            Server.clients[id].player.codeResult[Queue].Gold += Constants.gpm;
            Server.clients[id].player.shop.addGold(Constants.gpm);

            //Console.WriteLine($"{id} {tx} {ty}");

            if (Field[tx, ty].enemyMod == mods.Voltmeter && Field[tx, ty].playerMod != mods.Voltmeter)
            {
                Player p = Server.clients[Server.clients[id].player.enemyId].player;

                p.debugTexts.Add($"{Queue}. DETECTED LOAD IN STRUCT");
                p.debugIcons.Add(1);
                p.debugPos.Add(p.debugTexts.Count - 1, new Vector2(tx, ty));
            }
        }

        public bool checkConnections(Vector2 from, Vector2 to, Vector2 dir, int id)
        {
            //Console.WriteLine($"{Server.clients[id].player.Username} is trying to move it's load from {from} to {to}");

            int fx = (int)from.X;
            int fy = (int)from.Y;
            int tx = (int)to.X;
            int ty = (int)to.Y;

            if (tx >= fieldSizeX || tx < 0 || ty >= fieldSizeY || ty < 0) return false;
            if (Field[fx, fy] == null || Field[tx, ty] == null) return false;
            if (Field[tx, ty].Player != id) return false;
            if (dir == new Vector2(0, 1))
            {
                return Field[fx, fy].Connections[0] && Field[tx, ty].Connections[2];
            }
            else if (dir == new Vector2(1, 0))
            {
                return Field[fx, fy].Connections[1] && Field[tx, ty].Connections[3];
            }
            else if (dir == new Vector2(0, -1))
            {
                return Field[fx, fy].Connections[2] && Field[tx, ty].Connections[0];
            }
            else
            {
                return Field[fx, fy].Connections[3] && Field[tx, ty].Connections[1];
            }
        }

        public void setActive(bool a, Structures s, bool skipEMP)
        {
            if ((s.Type == sts.Wire || s.Type == sts.Base) || (a && s.enemyMod == mods.Worker && s.playerMod != mods.Worker)) return;

            int id = s.Player;
            Player p = Server.clients[id].player;

            p.codeResult[Queue].newActiveCords.Add(new Vector2(s.posX, s.posY));
            p.codeResult[Queue].newActiveStatus.Add(a);

            int x = (int)s.posX;
            int y = (int)s.posY;

            if (nearStruct(s.posX, s.posY, empRange, sts.EMP) && s.Type != sts.EMP && !skipEMP && a) return;

            if (a)
            {
                s.Worked = s.timeToWork;

                s.currentActive = true;
                activeStructs.Add(s);

                switch ((int)s.Type)
                {
                    case 2:
                        voltShoot(new Vector2(s.targetX, s.targetY), new Vector2(s.posX, s.posY), id);
                        break;
                    case 3:
                        EMP(s.posX, s.posY, empRange);
                        break;
                    case 4:
                        launchRocket(new Vector2(s.targetX, s.targetY), new Vector2(s.posX, s.posY), id);
                        break;
                    case 5:
                        break;
                    case 6:
                        Radar(s.targetX, s.targetY, s.Player);
                        break;
                    case 7:
                        bool booster = nearStruct(s.posX, s.posY, busterRange, sts.Buster, s.Player);
                        if (booster)
                        {
                            p.codeResult[Queue].Gold += goldFromMine * 2;
                            p.shop.addGold(goldFromMine * 2);
                        }
                        else
                        {
                            p.codeResult[Queue].Gold += goldFromMine;
                            p.shop.addGold(goldFromMine);
                        }
                        break;
                }
            }
            else
            {
                s.currentActive = s.defaultActive;
                /*switch ((int)s.Type)
                {
                    case 3:
                        break;
                    case 5:
                        break;
                    case 6:
                        break;
                }*/
            }
        }

        private void Radar(int x, int y, int player)
        {
            if (x == -1 && y == -1)
            {
                Server.clients[player].player.debugTexts.Add($"{Queue}. UNSETTED TARGET OF RADAR");
                Server.clients[player].player.debugIcons.Add(0);
                return;
            }
            else if(x < 0 || y < 0 || x >= fieldSizeX || y >= fieldSizeY)
            {
                Server.clients[player].player.debugTexts.Add($"{Queue}. RADAR'S TARGET IS NOT ON FIELD");
                Server.clients[player].player.debugIcons.Add(0);
                return;
            }

            int range = radarRange;

            for (int i = Math.Max(x - range, 0); i <= Math.Min(x + range, fieldSizeX - 1); i++)
            {
                for (int j = Math.Max(y - range, 0); j <= Math.Min(y + range, fieldSizeY - 1); j++)
                {
                    if (Field[i, j] != null && Field[i, j].Load)
                    {
                        Player p = Server.clients[player].player;
                        p.debugTexts.Add($"{Queue}. DETECTED LOAD IN STRUCT BY RADAR");
                        p.debugIcons.Add(1);
                        p.debugPos.Add(p.debugTexts.Count - 1, new Vector2(i, j));
                    }
                }
            }
        }

        private void EMP(int x, int y, int range) //Range is raduis (range = 2 => 5 cells area)
        {
            for (int i = Math.Max(x - range, 0); i <= Math.Min(x + range, fieldSizeX - 1); i++)
            {
                for (int j = Math.Max(y - range, 0); j <= Math.Min(y + range, fieldSizeY - 1); j++)
                {
                    if ((Field[i, j] != null) && Field[i, j].Type != sts.EMP && Field[i, j].Type != sts.Wire) setActive(false, Field[i, j], false);
                }
            }
        }

        public bool nearStruct(int x, int y, int range, int p) //default range == 1, p - player, which structs you want to detect
        {
            bool res = false;

            for (int i = Math.Max(x - range, 0); i <= Math.Min(x + range, fieldSizeX - 1); i++)
            {
                for (int j = Math.Max(y - range, 0); j <= Math.Min(y + range, fieldSizeY - 1); j++)
                {
                    if (Field[i, j] != null)
                    {
                        if (Field[i, j].Player == p)
                        {
                            res = true;
                            break;
                        }
                    }
                }
            }

            return res;
        }

        public List<Structures> getAllStructs()
        {
            List<Structures> res = new List<Structures>();

            for (int i = 0; i < fieldSizeX; i++)
            {
                for (int j = 0; j < fieldSizeY; j++)
                {
                    if (Field[i, j] != null) res.Add(Field[i, j]);
                }
            }

            return res;
        }

        private void voltShoot(Vector2 target, Vector2 start, int id)
        {
            int x = (int)target.X;
            int y = (int)target.Y;

            Player player = Server.clients[id].player;

            if (x < 0 || x >= fieldSizeX || y < 0 || y > fieldSizeY)
            {
                if (x == -1 && y == -1)
                {
                    player.debugTexts.Add($"{Queue}. UNSETTED TARGET OF VOLT DESTROYER");
                    player.debugIcons.Add(0);
                    player.debugPos.Add(player.debugTexts.Count - 1, new Vector2(start.X, start.Y));
                }
                else
                {
                    player.debugTexts.Add($"{Queue}. VOLT DESTROYER'S TARGET IS NOT ON FIELD");
                    player.debugIcons.Add(0);
                    player.debugPos.Add(player.debugTexts.Count - 1, new Vector2(start.X, start.Y));
                }
                return;
            }

            int range = voltDevourRange; //Range on which struct can be destroyed
            float dist = Vector2.Distance(start, target);
            if (dist > range)
            {
                player.debugTexts.Add($"{Queue}. TARGET IS OF VOLT DESTROYER ISN'T IN IT'S SHOOT RANGE");
                player.debugIcons.Add(0);
                player.debugPos.Add(player.debugTexts.Count - 1, new Vector2(start.X, start.Y));
                return;
            }

            if (Field[x, y] != null)
            {
                if (Field[x, y].Load)
                {
                    Player p = Server.clients[Field[x, y].Player].player;
                    int q = Queue;

                    p.playerLoad = null;
                    p.codeResult[q].Lose = true;
                    Server.clients[p.enemyId].player.codeResult[q].Win = true;

                    win = true;

                    Console.WriteLine($"Player {p.Username} Lose; Player {Server.clients[p.enemyId].player.Username} Win");

                    /*string debug = $"{Queue}. DESTROYED LOAD (POS: {x}, {y})";
                    Server.clients[id].player.debugTexts.Add(debug);
                    Server.clients[id].player.debugIcons.Add(1);*/
                }
                Field[x, y].Load = false;
            }
            else
            {
                player.debugTexts.Add($"{Queue}. TRYING TO GET ACCESS TO THE STRUCT, BUT IT DOESN'T EXIST");
                player.debugIcons.Add(0);
                player.debugPos.Add(player.debugTexts.Count - 1, new Vector2(start.X, start.Y));
            }
        }

        

        private void launchRocket(Vector2 target, Vector2 start, int id)
        {
            int x = (int)target.X;
            int y = (int)target.Y;

            Player player = Server.clients[id].player;

            if (x < 0 || x >= fieldSizeX || y < 0 || y > fieldSizeY)
            {
                if (x == -1 && y == -1)
                {
                    player.debugTexts.Add($"{Queue}. UNSETTED TARGET OF ROCKET LAUNCHER");
                    player.debugIcons.Add(0);
                    player.debugPos.Add(player.debugTexts.Count - 1, new Vector2(start.X, start.Y));
                }
                else
                {
                    player.debugTexts.Add($"{Queue}. ROCKET LAUNCHER'S TARGET IS NOT ON FIELD");
                    player.debugIcons.Add(0);
                    player.debugPos.Add(player.debugTexts.Count - 1, new Vector2(start.X, start.Y));
                }
                return;
            }

            int range = rocketLauncherRange; //Range on which struct can be destroyed
            float dist = Vector2.Distance(start, target);
            if (dist > range)
            {
                player.debugTexts.Add($"{Queue}. TARGET IS OF ROCKET LAUNCHER ISN'T IN IT'S SHOOT RANGE");
                player.debugIcons.Add(0);
                player.debugPos.Add(player.debugTexts.Count - 1, new Vector2(start.X, start.Y));
                return;
            }

            if (Field[x, y] != null)
            {
                if (!nearStruct(Field[x, y].posX, Field[x, y].posY, rocketShieldRange, sts.Shield))
                {
                    toDestroy.Add(Field[x, y]);

                    if (Field[x, y].Health == 1)
                    {
                        string debug = $"{Queue}. DESTROYED STRUCT";
                        player.debugTexts.Add(debug);
                        player.debugIcons.Add(1);
                        player.debugPos.Add(player.debugTexts.Count - 1, new Vector2(x, y));

                        int e = Server.clients[id].player.enemyId;

                        debug = $"{Queue}. YOUR STRUCT DESTROYED";
                        Server.clients[e].player.debugPos.Add(Server.clients[e].player.debugTexts.Count, new Vector2(x, y));
                        Server.clients[e].player.debugTexts.Add(debug);
                        Server.clients[e].player.debugIcons.Add(0);
                    }
                    else
                    {
                        string debug = $"{Queue}. DAMAGED STRUCT";
                        player.debugTexts.Add(debug);
                        player.debugIcons.Add(1);
                        player.debugPos.Add(player.debugTexts.Count - 1, new Vector2(x, y));

                        int e = Server.clients[id].player.enemyId;

                        debug = $"{Queue}. YOUR STRUCT DAMAGED";
                        Server.clients[e].player.debugPos.Add(Server.clients[e].player.debugTexts.Count, new Vector2(x, y));
                        Server.clients[e].player.debugTexts.Add(debug);
                        Server.clients[e].player.debugIcons.Add(0);
                    }
                }
                else
                {
                    string debug = $"{Queue}. STRUCT WAS DEFENDED BY SHIELD";
                    player.debugTexts.Add(debug);
                    player.debugIcons.Add(2);
                    player.debugPos.Add(player.debugTexts.Count - 1, new Vector2(x, y));

                    int e = Server.clients[id].player.enemyId;

                    debug = $"{Queue}. YOUR STRUCT WAS DEFENDED BY SHIELD";
                    Server.clients[e].player.debugTexts.Add(debug);
                    Server.clients[e].player.debugIcons.Add(1);
                }
            }
            else
            {
                player.debugTexts.Add($"{Queue}. TRYING TO GET ACCESS TO THE STRUCT, BUT IT DOESN'T EXIST");
                player.debugIcons.Add(0);
                player.debugPos.Add(player.debugTexts.Count - 1, new Vector2(start.X, start.Y));
            }
        }

        private bool nearStruct(int x, int y, int range, sts type) //Range is raduis (range = 2 => 5 cells area)
        {
            bool res = false;

            for (int i = Math.Max(x - range, 0); i <= Math.Min(x + range, fieldSizeX - 1); i++)
            {
                for (int j = Math.Max(y - range, 0); j <= Math.Min(y + range, fieldSizeY - 1); j++)
                {
                    if (Field[i, j] != null)
                    {
                        if (Field[i, j].Type == type && Field[i, j].currentActive)
                        {
                            if (type == sts.Shield)
                            {
                                res = !nearStruct(x + i, y + j, empRange, sts.EMP);
                            }
                            else { res = true; break; }
                        }
                    }
                }
            }

            return res;
        }

        private bool nearStruct(int x, int y, int range, sts type, int player) //Range is raduis (range = 2 => 5 cells area)
        {
            bool res = false;

            for (int i = Math.Max(x - range, 0); i <= Math.Min(x + range, fieldSizeX - 1); i++)
            {
                for (int j = Math.Max(y - range, 0); j <= Math.Min(y + range, fieldSizeY - 1); j++)
                {
                    if (Field[i, j] != null)
                    {
                        if (Field[i, j].Type == type && Field[i, j].currentActive && Field[i, j].Player == player)
                        {
                            if (type == sts.Shield)
                            {
                                res = !nearStruct(x + i, y + j, empRange, sts.EMP);
                            }
                            else { res = true; break; }
                        }
                    }
                }
            }

            return res;
        }

        private bool notChangedStatus(gameStatus a)
        {
            return a.loadPos == new Vector2(-1, -1) && a.loadRot == 0 && a.newActiveCords.Count == 0 && a.newActiveStatus.Count == 0 && a.removedStructs.Count == 0;
        }

        public void getReady()
        {
            if (bothPlayersReady())
            {
                if (currentStage != Stages.Coding) changeStage(false, 0);
                else runCode();
            }
        }

        private bool bothPlayersReady()
        {
            bool res = true;
            foreach (Client c in Server.clients.Values)
            {
                if (c.player != null && !c.player.Ready) { res = false; break; }
            }
            return res;
        }

        public void timeOutStage()
        {
            if (DateTime.Now > stageEnd && (stageTimeLim || currentStage == Stages.Viewing))
            {
                if (currentStage != Stages.Coding) changeStage(false, 0);
                else runCode();
            }
        }

        private void setStageEnd(int lastIndex)
        {
            stageEnd = DateTime.Now;

            if (currentStage != Stages.Viewing) stageEnd = stageEnd.AddSeconds(Constants.stagesLength[(int)currentStage]);
            else
            {
                Console.WriteLine($"Turns = {lastIndex}, view time {lastIndex * Constants.turnTime}");
                stageEnd = stageEnd.AddSeconds(lastIndex * Constants.turnTime);
            }

            Console.WriteLine($"Now: {DateTime.Now}, Stage end: {stageEnd}");
        }

        public void changeStage(bool ignoreCode, int lastIndex)
        {
            switch (currentStage)
            {
                case Stages.Building:
                    Ter.calculateTerritory();
                    break;
                case Stages.Modding:
                    break;
                case Stages.Coding:
                    //if (!ignoreCode) runCode();
                    if (ignoreCode) currentStage = Stages.Viewing;
                    break;
                case Stages.Viewing:
                    break;
            }

            int st = (int)currentStage;
            currentStage = (Stages)((st + 1) % 4);

            setStageEnd(lastIndex);

            foreach (Client c in Server.clients.Values)
            {
                if (c.player != null) c.player.Ready = false;
            }

            ServerSend.sendNewStage((int)currentStage, stageEnd.Ticks);
        }
    }
}
