﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace Volt_Server
{
    class Server
    {
        public static int maxPlayers { get; private set; }
        public static int Port { get; private set; }
        public static Dictionary<int, Client> clients = new Dictionary<int, Client>(); //Key - client's id

        public delegate void PacketHandler(int _fromClient, Packet _packet);
        public static Dictionary<int, PacketHandler> packetHandlers = new Dictionary<int, PacketHandler>();

        private static TcpListener tcplistener;

        public static gameLoop GL;
        public static Territory Ter;

        public static void Start(int _maxPlayers, int _port)
        {
            maxPlayers = _maxPlayers;
            Port = _port;

            Console.WriteLine("Starting Server...");
            initializeServerData();

            tcplistener = new TcpListener(IPAddress.Any, Port);
            tcplistener.Start();
            tcplistener.BeginAcceptTcpClient(new AsyncCallback(TCPConnectCallback), null);

            Console.WriteLine($"Server started on {Port}.");
        }

        private static void TCPConnectCallback(IAsyncResult _result)
        {
            TcpClient _client = tcplistener.EndAcceptTcpClient(_result);
            tcplistener.BeginAcceptTcpClient(new AsyncCallback(TCPConnectCallback), null);
            Console.WriteLine($"Incoming connection from {_client.Client.RemoteEndPoint}...");

            for (int i = 1; i <= maxPlayers; i++)
            {
                if (clients[i].tcp.socket == null)
                {
                    clients[i].tcp.Connect(_client);
                    return;
                }
            }

            Console.WriteLine($"{_client.Client.RemoteEndPoint} failed to connect: Server full!");
        }

        private static void initializeServerData()
        {
            for (int i = 1; i <= maxPlayers; i++)
            {
                clients.Add(i, new Client(i));
            }

            packetHandlers = new Dictionary<int, PacketHandler>()
            {
                {(int)ClientPackets.welcomeReceived, ServerHandle.WelcomeReceived },
                {(int)ClientPackets.buy, ServerHandle.buy },
                {(int)ClientPackets.placeStruct, ServerHandle.setStruct },
                {(int)ClientPackets.removeStruct, ServerHandle.removeStruct },
                {(int)ClientPackets.sellStruct, ServerHandle.sellStruct },
                {(int)ClientPackets.sendCode, ServerHandle.sendCode },
                {(int)ClientPackets.editTarger, ServerHandle.getNewTarger },
                {(int)ClientPackets.editMod, ServerHandle.getNewMod },
                {(int)ClientPackets.Ready, ServerHandle.getReady },
                {(int)ClientPackets.changePar, ServerHandle.changePar },
                {(int)ClientPackets.rotateStruct, ServerHandle.rotateStruct }
            };

            Console.WriteLine("Packets initialized!");
        }
    }
}
