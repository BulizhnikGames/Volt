﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Volt_Server
{
    class Constants
    {
        public const int TICKS_PER_SEC = 64;
        public const int MS_PER_TICK = 1000 / TICKS_PER_SEC;
        public const int fieldSizeX = 40;
        public const int fieldSizeY = 20;
        public static readonly int[] stagesLength = new int[3] { 60, 60, 60};
        public const float turnTime = 0.25f;
        public const int gpm = 5; //Gold per move
    }
}
