﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Volt_Server
{
    class ServerHandle
    {
        public static void WelcomeReceived(int _fromClient, Packet _packet)
        {
            int _clientIdCheck = _packet.ReadInt();
            string _username = _packet.ReadString();

            Console.WriteLine($"{_username} (IP: {Server.clients[_fromClient].tcp.socket.Client.RemoteEndPoint}) connected successfully and now is player {_fromClient}");

            if (_fromClient != _clientIdCheck)
            {
                Console.WriteLine($"Player \"{_username}\" (ID: {_fromClient}) has assumed the wrong client ID ({_clientIdCheck})!");
            }

            Server.clients[_fromClient].SendIntoGame(_username);
        }

        public static void buy(int _fromClient, Packet _packet)
        {
            int _index = _packet.ReadInt();

            if (Server.GL.currentStage != Stages.Building) return;

            Server.clients[_fromClient].player.shop.Buy(_index);
        }

        public static void setStruct(int _fromClient, Packet _packet)
        {
            Structures s = _packet.ReadStruct();

            if (Server.GL.currentStage != Stages.Building) return;

            Server.clients[_fromClient].player.sp.createStruct(s);
        }

        public static void removeStruct(int _fromClient, Packet _packet)
        {
            int x = _packet.ReadInt();
            int y = _packet.ReadInt();
            int index = _packet.ReadInt();

            if (Server.GL.currentStage != Stages.Building || Server.GL.Field[x, y].Type == sts.Base) return;

            Server.clients[_fromClient].player.shop.Remove(x, y);
            Server.clients[_fromClient].player.sp.removeStruct(x, y); 
        }

        public static void sellStruct(int _fromClient, Packet _packet)
        {
            int x = _packet.ReadInt();
            int y = _packet.ReadInt();
            int index = _packet.ReadInt();

            if (Server.GL.currentStage != Stages.Building || Server.GL.Field[x, y].Type == sts.Base) return;

            Server.clients[_fromClient].player.shop.Sell(x, y);
            Server.clients[_fromClient].player.sp.removeStruct(x, y);
        }

        public static void sendCode(int _fromClient, Packet _packet)
        {
            int Line = _packet.ReadInt();
            Block newBlock = _packet.ReadBlock();
            bool remove = _packet.ReadBool();
            int prevLine = _packet.ReadInt();

            //Console.WriteLine($"Line {Line}, Prev Line {prevLine}, conLine {newBlock.conLine}");

            if (Server.GL.currentStage != Stages.Coding) return;

            Player p = Server.clients[_fromClient].player;

            if (remove)
            {
                if (prevLine >= 0 && prevLine < 20)
                {
                    Block b = p.Code[prevLine];

                    if (b == null) return;

                    if (b.conLine >= 0 && b.conLine < 20) p.Code[b.conLine] = null;
                    p.Code[prevLine] = null;
                }
            }
            else
            {
                if (prevLine >= 0 && prevLine < 20) p.Code[prevLine] = null;
                p.Code[Line] = newBlock;

                if (newBlock.conLine >= 0 && newBlock.conLine < 20 && p.Code[newBlock.conLine] != null)
                {
                    p.Code[newBlock.conLine].conLine = Line;
                }
            }
        }

        public static void getNewTarger(int _fromClient, Packet _packet)
        {
            int posX = _packet.ReadInt();
            int posY = _packet.ReadInt();

            int tarX = _packet.ReadInt();
            int tarY = _packet.ReadInt();

            if (Server.GL.currentStage != Stages.Modding || Server.GL.Field[posX, posY].Type == sts.Base) return;

            Structures s = Server.clients[_fromClient].GL.Field[posX, posY];
            int Owner = s.Player;

            if (_fromClient == Owner)
            {
                s.targetX = tarX;
                s.targetY = tarY;

                if (s.enemyMod == mods.Tracker && s.playerMod != mods.Tracker) ServerSend.updateTarget(Server.clients[Owner].player.enemyId, s);

                Console.WriteLine($"Pos: {posX}, {posY}; Target: {tarX}, {tarY}");
            }
        }

        public static void getNewMod(int _fromClient, Packet _packet)
        {
            int posX = _packet.ReadInt();
            int posY = _packet.ReadInt();

            int newMod = _packet.ReadInt();

            Player p = Server.clients[_fromClient].player;

            if (Server.GL.currentStage != Stages.Modding || Server.GL.Field[posX, posY].Type == sts.Base) return;

            Structures s = Server.clients[_fromClient].GL.Field[posX, posY];
            int Owner = s.Player;

            if (newMod > 0)
            {
                int maxMods = p.shop.maxMods[newMod - 1];
                int placedMods = p.shop.modsPlaced[newMod - 1];
                if (placedMods == maxMods) return;

                p.shop.modsPlaced[newMod - 1]++;
            }

            if (_fromClient == Owner)
            {
                if (s.playerMod != mods.None) p.shop.modsPlaced[(int)s.playerMod - 1]--;

                ServerSend.applyMod(_fromClient, posX, posY, newMod, true, true);
                s.playerMod = (mods)newMod;

                Console.WriteLine($"Pos: {posX}, {posY}; new mod = {newMod} PLAYER'S");

                if (s.playerMod == mods.Tracker && s.enemyMod != mods.Tracker) ServerSend.applyMod(_fromClient, posX, posY, (int)s.enemyMod, false, false);
                if (s.enemyMod == mods.Tracker && s.playerMod != mods.Tracker)
                {
                    ServerSend.applyMod(Server.clients[_fromClient].player.enemyId, posX, posY, newMod, true, false);
                    ServerSend.updateTarget(Server.clients[_fromClient].player.enemyId, s);
                }
            }
            else
            {
                if (s.enemyMod != mods.None) p.shop.modsPlaced[(int)s.enemyMod - 1]--;

                ServerSend.applyMod(_fromClient, posX, posY, newMod, false, true);
                s.enemyMod = (mods)newMod;

                Console.WriteLine($"Pos: {posX}, {posY}; new mod = {newMod} NOT PLAYER'S");

                if (s.enemyMod == mods.Tracker && s.playerMod != mods.Tracker)
                {
                    ServerSend.applyMod(_fromClient, posX, posY, (int)s.playerMod, true, false);
                    ServerSend.updateTarget(_fromClient, s);
                }
                if (s.playerMod == mods.Tracker && s.enemyMod != mods.Tracker) ServerSend.applyMod(s.Player, posX, posY, newMod, false, false);  
            }
        }

        public static void getReady(int _fromClient, Packet _packet)
        {
            Server.clients[_fromClient].player.Ready = !Server.clients[_fromClient].player.Ready;
            ServerSend.applyReady(_fromClient);
            Server.GL.getReady();
        }

        public static void changePar(int _fromClient, Packet _packet)
        {
            int Line = _packet.ReadInt();
            int Par = _packet.ReadInt();

            if (Server.GL.currentStage != Stages.Coding) return;

            Server.clients[_fromClient].player.Code[Line].Par = Par;
        }

        public static void rotateStruct(int _fromClient, Packet _packet)
        {
            int x = _packet.ReadInt();
            int y = _packet.ReadInt();

            int Rotation = _packet.ReadInt();

            if (Server.GL.currentStage != Stages.Building || Server.GL.Field[x, y] == null || Server.GL.Field[x, y].allSide()) return;

            Server.clients[_fromClient].player.sp.rotateStruct(x, y, Rotation);
        }
    }
}
