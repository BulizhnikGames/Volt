﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Numerics;

namespace Volt_Server
{

    public enum blockTypes { moveUp, moveDown, moveRight, moveLeft, startRepeat, endRepeat, Forward, Bakcward, turnRight, turnLeft, Activate };

    public class Block
    {
        public blockTypes Type = 0;
        public int Par = 0;
        public int cyclesPassed = 0;

        public Block Connected;
        public Block nextBlock;

        public gameLoop GL;
        public Player player;

        public int Line = 0;
        public int conLine = -1;

        public void Execute()
        {
            if (Type != blockTypes.startRepeat && Type != blockTypes.endRepeat) Console.WriteLine($"{player.id}.{GL.Queue} {Type}");
            if (player.playerLoad == null)
            {
                Console.WriteLine($"Player {player.Username} load is destroyed; can't go on");
                return;
            }
            switch ((int)Type)
            {
                case 0: //Move up
                case 1: //Move down
                case 2: //Move right
                case 3: //Move left
                case 6: //Move unit forward
                case 7: //Move unit backward
                case 8: //Rotate unit to the right
                case 9: //Rotate unit to the left
                    player.moveUnit(Type);
                    break;
                case 5: //End repeat (check if need to repeat code)
                    //int q = GL.Queue;
                    //if (q > 0) player.codeResult[q].loadPos = player.codeResult[q - 1].loadPos;

                    cyclesPassed++;
                    break;
                case 10: //Activate
                    int _q = GL.Queue;
                    if (_q > 0 ) player.codeResult[_q].loadPos = player.codeResult[_q - 1].loadPos;

                    player.activeField(Par);
                    break;
            }

            if (player.canGoOn() && !(Connected == null && nextBlock == null)) // || (nextBlock != null && nextBlock.Type == blockTypes.endRepeat && nextBlock.Connected.Par >= nextBlock.cyclesPassed + 1)
            {
                if (Type == blockTypes.startRepeat)
                {
                    nextBlock.Execute();
                }
                else if (Type == blockTypes.endRepeat)
                {
                    if (Connected.Par > cyclesPassed)
                    {
                        Connected.Execute();
                    }
                    else
                    {
                        cyclesPassed = 0;
                        if (nextBlock != null) nextBlock.Execute();
                        else player.endOfCode();
                    }
                }
                else
                {
                    GL.toExec.Add(nextBlock);
                }
            }
            else
            {
                player.endOfCode();
            }
        }

        public override string ToString()
        {
            return "TYPE = " + Type.ToString() + "; PAR = " + Par.ToString();
        }
    }
}
