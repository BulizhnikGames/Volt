﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Numerics;

namespace Volt_Server
{
    public class gameStatus
    {
        public Vector2 loadPos;
        public int loadRot;
        public List<Vector2> newActiveCords;
        public List<bool> newActiveStatus;
        public List<Vector2> removedStructs;
        public bool Win = false;
        public bool Lose = false;
        public int Gold = 0;

        public gameStatus()
        {
            loadPos = new Vector2(-1, -1);
            loadRot = 0;
            newActiveCords = new List<Vector2>();
            newActiveStatus = new List<bool>();
            removedStructs = new List<Vector2>();
            Win = false;
            Lose = false;
            Gold = 0;
        }

        public override string ToString()
        {
            return $"lp {loadPos} nac.l = {newActiveCords.Count} nav.l = {newActiveStatus.Count} rs.l = {removedStructs.Count}";
        }
    }
}
