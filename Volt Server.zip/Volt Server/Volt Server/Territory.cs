﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Numerics;

namespace Volt_Server
{
    public class Territory
    {
        public int[,] Ter;
        private int fieldSizeX = 40;
        private int fieldSizeY = 20;
        private int id1;
        private int id2;
        private Vector2[] roundStartPrices;
        private gameLoop GL;

        private Vector2 Amounts = new Vector2(400, 400);

        public Territory(int _id1, int _id2, gameLoop _gl)
        {
            id1 = _id1;
            id2 = _id2;
            GL = _gl;
            initTerritory();
        }

        public void initTerritory()
        {
            int x = fieldSizeX;
            int y = fieldSizeY;

            Ter = new int[x, y];

            roundStartPrices = new Vector2[y];

            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    if (i < x / 2)
                    {
                        Ter[i, j] = id1;
                    }
                    else
                    {
                        Ter[i, j] = id2;
                    }

                    roundStartPrices[j] = Vector2.Zero;
                }  
            }

            devideTerritories();
        }

        public void calculateTerritory()
        {
            for (int y = 0; y < fieldSizeY; y++)
            {
                int playerSum = 0;
                int enemySum = 0;

                int startInt = Ter[0, y];
                int changeIndex = -1;

                for (int x = 0; x < GL.fieldSizeX; x++)
                {
                    if (GL.Field[x, y] != null)
                    {
                        if (Ter[x, y] == id1) playerSum += Shop.Prices[GL.Field[x, y].shopIndex];
                        else enemySum += Shop.Prices[GL.Field[x, y].shopIndex];
                    }

                    if (Ter[x, y] != startInt && changeIndex < 0) changeIndex = x;
                }

                if (changeIndex == GL.fieldSizeX - 1) continue;

                if (roundStartPrices[y] != new Vector2(playerSum, enemySum))
                {
                    if (startInt == id1)
                    {
                        if ((playerSum >= enemySum * 2 && (playerSum < enemySum * 3.5f || enemySum == 0)) || (enemySum >= playerSum * 3.5f && playerSum != 0)) Ter[changeIndex, y] = id1;
                        else if ((enemySum >= playerSum * 2 && (enemySum < playerSum * 3.5f || playerSum == 0)) || (playerSum >= enemySum * 3.5f && enemySum != 0)) Ter[changeIndex - 1, y] = id2;
                    }
                    else
                    {
                        if ((playerSum >= enemySum * 2 && (playerSum < enemySum * 3.5f || enemySum == 0)) || (enemySum >= playerSum * 3.5f && playerSum != 0)) Ter[changeIndex - 1, y] = id1;
                        else if ((enemySum >= playerSum * 2 && (enemySum < playerSum * 3.5f || playerSum == 0)) || (playerSum >= enemySum * 3.5f && enemySum != 0)) Ter[changeIndex, y] = id2;
                    }
                }

                roundStartPrices[y] = new Vector2(playerSum, enemySum);
            }

            devideTerritories();
        }

        public void devideTerritories()
        {
            ServerSend.devideTerrs(Ter, roundStartPrices);

            Amounts = Vector2.Zero;

            for (int x = 0; x < fieldSizeX; x++)
            {
                for (int y = 0; y < fieldSizeY; y++)
                {
                    if (Ter[x, y] == id1) Amounts.X++;
                    else Amounts.Y++;
                }
            }

            Console.WriteLine($"{Server.clients[id1].player.Username}'s amount: {Amounts.X}; {Server.clients[id2].player.Username}'s amount: {Amounts.Y}");

            if (Amounts.X >= 480)
            {
                ServerSend.gameEnd(id1, true);
                ServerSend.gameEnd(id2, false);
            }
            else if (Amounts.Y >= 480)
            {
                ServerSend.gameEnd(id1, false);
                ServerSend.gameEnd(id2, true);
            }

            GL.win = Amounts.X >= 480 || Amounts.Y >= 480;
        }
    }
}
