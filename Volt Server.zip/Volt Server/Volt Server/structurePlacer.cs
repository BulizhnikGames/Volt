﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Numerics;

namespace Volt_Server
{
    public class structurePlacer
    {
        public Player player;
        private List<Structures> Structs;

        public void createStruct(Structures Struct) //rr = rotation right, rl - rotation left
        {
            Struct.Player = player.id;
            if (!player.shop.canPlace(Struct.shopIndex) || !checkTerritory(Struct.posX, Struct.posY, Struct)) return;

            if (Struct.Rotation > 0)
            {
                for (int i = 0; i < Struct.Rotation; i++)
                {
                    Struct.rotateRight();
                }
            }
            else if (Struct.Rotation < 0)
            {
                for (int i = 0; i > Struct.Rotation; i--)
                {
                    Struct.rotateLeft();
                }
            }   

            player.client.GL.addToField(new Vector2(Struct.posX, Struct.posY), Struct);

            player.shop.Place(Struct.shopIndex);
            ServerSend.changeCanPlace(player.id, Struct.shopIndex, player.shop.canPlace(Struct.shopIndex), true, player.shop.inInventory());
            ServerSend.setStruct(Struct);

            //Console.WriteLine($"Placed struct: type {Struct.Type}, time to work {Struct.timeToWork}, player {Struct.Player}, default active {Struct.defaultActive}, sprite {Struct.sprite}, rotation {Struct.Rotation}, pos {new Vector2(Struct.posX, Struct.posY)}, shop index {Struct.shopIndex}");
        }

        public void removeStruct(int x, int y)
        {
            Server.GL.Field[x, y] = null;
            ServerSend.removeStruct(x, y);
        }

        private bool checkTerritory(int x, int y, Structures s)
        {
            //Console.WriteLine($"Territory {player.client.Ter.Ter[x, y]}, structure's player {s.Player}");
            //return shop.Territory[x, y] == Struct.Player && shop.Territory[x, y] == shop.Territory[Mathf.Min(x + 1, GL.fieldSizeX - 1), y] && shop.Territory[x, y] == shop.Territory[Mathf.Max(x - 1, 0), y];
            return player.client.Ter.Ter[x, y] == s.Player;
        }

        public void rotateStruct(int x, int y, int r)
        {
            Structures s = player.GL.Field[x, y];

            if (r > 0)
            {
                for (int i = 0; i < r; i++)
                {
                    s.rotateRight();
                }
            }
            else if (r < 0)
            {
                for (int i = 0; i > r; i--)
                {
                    s.rotateLeft();
                }
            }

            s.Rotation += r;

            ServerSend.applyRotation(x, y, r);
        }
    }
}
